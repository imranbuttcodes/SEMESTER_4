#include "temperature.h"
#include <iostream>
using namespace std;

int main() {
    // Create weather station that can store 7 days of temperatures
    Temperature week1(7);
    
    cout << "\n=== Recording Daily Temperatures ===" << endl;
    
    // Add temperature readings for a week
    week1.addTemperature(23.5);
    week1.addTemperature(25.0);
    week1.addTemperature(22.8);
    week1.addTemperature(26.2);
    week1.addTemperature(24.1);
    week1.addTemperature(21.9);
    week1.addTemperature(27.3);
    
    // Try to add one more (exceeds capacity)
    week1.addTemperature(28.0);
    
    // Display all temperatures
    week1.displayTemperatures();
    
    // Calculate and display statistics
    cout << "\n=== Weather Statistics ===" << endl;
    cout << "Average temperature: " << week1.calculateAverage() << "°C" << endl;
    cout << "Highest temperature: " << week1.findHighest() << "°C" << endl;
    cout << "Lowest temperature: " << week1.findLowest() << "°C" << endl;
    
    // Destructor will automatically free memory
    cout << "\nProgram completed successfully." << endl;
    
    return 0;
}