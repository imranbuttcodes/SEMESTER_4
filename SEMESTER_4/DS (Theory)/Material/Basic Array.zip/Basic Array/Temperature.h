

class Temperature {
private:
    double* temperatures;  // Pointer to dynamically allocate array
    int capacity;          // Maximum capacity of array
    int count;             // Current number of records

public:
    // Constructor and Destructor
    Temperature(int size);
    ~Temperature();

    // Core functions
    void addTemperature(double temp);
    void displayTemperatures();
    double calculateAverage();
    double findHighest();
    double findLowest();
    void freeMemory();
};

