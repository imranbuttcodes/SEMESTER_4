#include "temperature.h"
#include <iostream>
using namespace std;

// Constructor - allocate memory
Temperature::Temperature(int size) {
    capacity = size;
    count = 0;
    temperatures = new double[capacity];
    cout << "Weather station initialized to store " << capacity << " temperature readings." << endl;
}

// Destructor - free memory
Temperature::~Temperature() {
    delete[] temperatures;
    cout << "Memory freed. Weather station shutting down." << endl;
}

// Add temperature reading
void Temperature::addTemperature(double temp) {
    if (count < capacity) {
        temperatures[count] = temp;
        cout << "Temperature " << temp << "°C recorded at position " << count << endl;
        count++;
    } else {
        cout << "Storage full! Cannot record more temperatures." << endl;
    }
}

// Display all temperatures
void Temperature::displayTemperatures() {
    cout << "\n=== Temperature Records ===" << endl;
    for (int i = 0; i < count; i++) {
        cout << "Day " << i + 1 << ": " << temperatures[i] << "°C" << endl;
    }
}

// Calculate average temperature
double Temperature::calculateAverage() {
    if (count == 0) {
        cout << "No temperature data available." << endl;
        return 0;
    }

    double sum = 0;
    for (int i = 0; i < count; i++) {
        sum += temperatures[i];
    }
    return sum / count;
}

// Find highest temperature
double Temperature::findHighest() {
    if (count == 0) {
        cout << "No temperature data available." << endl;
        return 0;
    }

    double highest = temperatures[0];
    for (int i = 1; i < count; i++) {
        if (temperatures[i] > highest) {
            highest = temperatures[i];
        }
    }
    return highest;
}

// Find lowest temperature
double Temperature::findLowest() {
    if (count == 0) {
        cout << "No temperature data available." << endl;
        return 0;
    }

    double lowest = temperatures[0];
    for (int i = 1; i < count; i++) {
        if (temperatures[i] < lowest) {
            lowest = temperatures[i];
        }
    }
    return lowest;
}

// Explicitly free memory
void Temperature::freeMemory() {
    delete[] temperatures;
    temperatures = nullptr;
    count = 0;
    capacity = 0;
    cout << "Memory manually freed." << endl;
}
